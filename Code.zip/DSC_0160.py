import numpy as np
import numpy
import cv2
from PIL import Image
import time

def read_image(path):
    input_image = cv2.imread(path, cv2.IMREAD_COLOR)
    input_image = cv2.cvtColor(input_image, cv2.COLOR_BGR2RGB)
    return input_image



def warp_image2(image, pts_template, pts_fabric):
    tps = cv2.createThinPlateSplineShapeTransformer()
    
    matches = list()
    for i in range(len(pts_template)):
        matches.append(cv2.DMatch(i,i,0))

    pts_fabric = pts_fabric.reshape(1,-1,2)
    pts_template = pts_template.reshape(1,-1,2)
    
 
    tps.estimateTransformation(pts_fabric,pts_template,matches)
    ret, pts_template_ = tps.applyTransformation(pts_fabric)
    tps.estimateTransformation(pts_template,pts_fabric,matches)
    im_out = tps.warpImage(image)
    
    return im_out
    


def final_proc_im(template_path, \
                  figure_path, \
                  pallu_path, \
                  blouse_path,\
                  mask_path,\
                  pts_figure1, \
                  pts_fabric_1, \
                  pts_fabric_2, \
                  pts_figure4,\
                  pts_pallu1,\
                  pts_blouse,\
                  pts_blouse_fabric,\
                  pts_plate_fabric,
                  pts_pallu_fabric,\
                  pts_plates1,\
                  pts_plates2,\
                  fill=1):
    start1 = time.time()
    template = numpy.array(cv2.resize(src=read_image(template_path), dsize=(2160,3240))).astype(float)
    figure = numpy.array(cv2.resize(src=read_image(figure_path), dsize=(2160,3240))).astype(float)
    pallu = numpy.array(cv2.resize(src=read_image(pallu_path), dsize=(2160,3240))).astype(float)
    blouse = numpy.array(cv2.resize(src=read_image(blouse_path), dsize=(2160,3240))).astype(float)
    
    template_fabric = np.copy(template)
    
    warped_image_figure_1 = warp_image2(figure, pts_figure1, pts_fabric_1)
    warped_image_figure_4 = warp_image2(figure, pts_figure4, pts_fabric_2)
    warped_image_pallu_1 = warp_image2(pallu, pts_pallu1, pts_pallu_fabric)
    
    warped_image_plate1 = warp_image2(figure, pts_plates1, pts_plate_fabric)
    warped_image_plate2 = warp_image2(figure, pts_plates2, pts_plate_fabric)
    
    warped_image_blouse = warp_image2(blouse, pts_blouse, pts_blouse_fabric)
    template_mask = cv2.resize(src=read_image(mask_path), dsize=(2160,3240), interpolation=cv2.INTER_NEAREST)
    
    figure_1_pixels = np.where(np.all(template_mask==[224,67,217], axis=-1))
    figure_2_pixels = np.where(np.all(template_mask==[38,38,38], axis=-1))
    figure_3_pixels = np.where(np.all(template_mask==[2,144,240], axis=-1))
    
    pallu_1_pixels = np.where(np.all(template_mask==[245,94,94], axis=-1))
    
    plate_1_pixels = np.where(np.all(template_mask==[30,95,170], axis=-1))
    plate_2_pixels = np.where(np.all(template_mask==[206,169,23], axis=-1))
        
    blouse_left_arm = np.where(np.all(template_mask==[139,217,1], axis=-1))
    mid_blouse = np.where(np.all(template_mask==[127,13,5], axis=-1))
    
    template_fabric[figure_1_pixels] = warped_image_figure_1[figure_1_pixels]
    template_fabric[figure_2_pixels] = warped_image_figure_4[figure_2_pixels]
    template_fabric[figure_3_pixels] = warped_image_figure_4[figure_3_pixels]

    template_fabric[pallu_1_pixels] = warped_image_pallu_1[pallu_1_pixels]
    
    template_fabric[plate_1_pixels] = warped_image_plate1[plate_1_pixels]
    template_fabric[plate_2_pixels] = warped_image_plate2[plate_2_pixels]
        
    template_fabric[blouse_left_arm] = warped_image_blouse[blouse_left_arm]
    template_fabric[mid_blouse] = warped_image_blouse[mid_blouse]
    
    return template_fabric



# These are the points you have to change
pts_fabric_figure_1 = np.array([[0, 0], [2160, 0], [2160, 2592], [2160, 2892], \
                       [2160, 2967], [2160, 3017], [2160, 3240], [0, 3240]], np.float32)

pts_fabric_figure_2 = np.array([[0, 0], [2160, 0], [2160, 3240], [0, 3240], \
                         [0, 2240], [0, 2040], [0, 1890], [0, 1690],\
                         [0, 1440]], np.float32)

pts_fabric_plates = np.array([[0, 3240], [0, 0],[2160, 0], [2160, 3240]], np.float32)

pts_template_figure_1 = np.array([[883, 116], [1454, 617], [752, 1948], [645, 2073],\
                                  [631, 2109], [633, 2134], [613, 2275], [10, 1048]], np.float32)


pts_template_figure_4 = np.array([[1708, 516], [2017, 1144], [738, 2033], [185, 1292],\
                                  [616, 833], [657, 735], [719, 664], [796, 604], \
                                  [989, 516]], np.float32)

pts_template_pallu_1 = np.array([[881, 1117], [926, 1117], [937, 1110], [1000, 1114],\
                              [1040, 1105], [1125, 1105], [1184, 1070], [2549, 1070], \
                              [2549, 2436], [1466, 2436], [1465, 2475], [1520, 2595], \
                              [1572, 2768], [1540, 2848], [1473, 3077], [1410, 3119], \
                              [1100, 3240], [1054, 3218], [967, 3137], [927, 3064], \
                              [897, 2946], [897, 2740], [858, 2148], [872, 1408], \
                              [907, 1210], [907, 1154]], np.float32)

pts_blouse = np.array([[0, 3240], [0, 0], [2160, 0], [2160, 3240]], np.float32)

pts_template_blouse = np.array([[482, 453], [1124, 453], [1124, 961], [482, 961]], np.float32)

pts_fabric_pallu = np.array([[0, 0], [75, 0], [100, 0], [200, 0],\
                            [275, 0], [375, 0], [475, 0], [2160, 0], \
                            [2160, 1700], [2160, 2400], [2160, 2500], [2160, 2800], \
                            [2160, 3240], [1900, 3240], [1500, 3240], [1300, 3240], \
                            [0, 3240], [0, 3140], [0, 2940], [0, 2800], \
                            [0, 2600], [0, 2350], [0, 1500], [0, 600], \
                            [0, 300], [0, 200]], np.float32)

pts_plates_1 = np.array([[45, 1330], [2028, 1330], [2028, 3053], [45, 3053]], np.float32)
pts_plates_2 = np.array([[182, 1289], [2160, 1289], [2160, 3010], [182, 3010]], np.float32)




final_image = final_proc_im(template_path='DSC_0160.JPG', \
                            figure_path='figure.jpg', \
                            mask_path='DSC_0160.png', \
                            pallu_path='Pallu3.JPG',\
                            blouse_path='Blouse.jpg',\
                            pts_figure1=pts_template_figure_1,\
                            pts_figure4=pts_template_figure_4,\
                            pts_fabric_1=pts_fabric_figure_1 ,\
                            pts_fabric_2=pts_fabric_figure_2,\
                            pts_pallu1=pts_template_pallu_1,\
                            pts_blouse=pts_template_blouse,\
                            pts_blouse_fabric=pts_blouse,\
                            pts_plate_fabric=pts_fabric_plates,\
                            pts_pallu_fabric=pts_fabric_pallu,\
                            pts_plates1=pts_plates_1,\
                            pts_plates2=pts_plates_2,\
                            fill=1)
fin = numpy.uint8(final_image)
final_image = Image.fromarray(fin)
final_image.save('outputfin_fabric.png')